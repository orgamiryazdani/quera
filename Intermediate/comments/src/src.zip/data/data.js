export const dataComments = [
  {
    id: 1,
    name: "Erfan",
    message: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos minus
    suscipit temporibus ipsa error asperiores sapiente alias excepturi
    quae repellat labore, cupiditate, et ratione officia nihil
    voluptatem. Deleniti, nemo provident.`,
    children: [
      {
        id: 11,
        name: "Mohammad",
        message: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos minus
            suscipit temporibus ipsa error asperiores sapiente alias excepturi
            quae repellat labore, cupiditate, et ratione officia nihil
            voluptatem. Deleniti, nemo provident.`,
        children: [],
      },
      {
        id: 12,
        name: "Mahyar",
        message: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos minus
            suscipit temporibus ipsa error asperiores sapiente alias excepturi
            quae repellat labore, cupiditate, et ratione officia nihil
            voluptatem. Deleniti, nemo provident.`,
        children: [],
      },
      {
        id: 13,
        name: "Salib",
        message: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos minus
            suscipit temporibus ipsa error asperiores sapiente alias excepturi
            quae repellat labore, cupiditate, et ratione officia nihil
            voluptatem. Deleniti, nemo provident.`,
        children: [],
      },
    ],
  },
  {
    id: 2,
    name: "Shamsollah",
    message: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos minus
    suscipit temporibus ipsa error asperiores sapiente alias excepturi
    quae repellat labore, cupiditate, et ratione officia nihil
    voluptatem. Deleniti, nemo provident.`,
    children: [
      {
        id: 21,
        name: "Yadollah",
        message: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos minus
            suscipit temporibus ipsa error asperiores sapiente alias excepturi
            quae repellat labore, cupiditate, et ratione officia nihil
            voluptatem. Deleniti, nemo provident.`,
        children: [],
      },
      {
        id: 22,
        name: "Saeed",
        message: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos minus
            suscipit temporibus ipsa error asperiores sapiente alias excepturi
            quae repellat labore, cupiditate, et ratione officia nihil
            voluptatem. Deleniti, nemo provident.`,
        children: [
          {
            id: 221,
            name: "Yousef",
            message: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos minus
                    suscipit temporibus ipsa error asperiores sapiente alias excepturi
                    quae repellat labore, cupiditate, et ratione officia nihil
                    voluptatem. Deleniti, nemo provident.`,
            children: [],
          },
        ],
      },
    ],
  },
  {
    id: 3,
    name: "Asghar",
    message: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos minus
    suscipit temporibus ipsa error asperiores sapiente alias excepturi
    quae repellat labore, cupiditate, et ratione officia nihil
    voluptatem. Deleniti, nemo provident.`,
    children: [],
  },
];
